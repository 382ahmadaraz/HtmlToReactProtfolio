import Navbar from '../../component/navbar/Navbar';
import Hero from '../../component/hero/Hero'

export default function Home( ) {
    return(
        <div>
            <Navbar/>
            <Hero/>
        </div>
    )
}